  <?php
  echo '<div class="element-item">
                                 <div class="tt-product-design02 thumbprod-center">
                            <div class="tt-image-box">
                                <a href="product.html">
                                    <span class="tt-img"><img src="images/product/product-27.jpg" alt=""></span>
                                </a>
                                <div class="tt-countdown_box">
                                    <div class="tt-countdown_inner">
                                        <div class="tt-countdown"
                                            data-date="2018-11-01"
                                            data-year="Yrs"
                                            data-month="Mths"
                                            data-week="Wk"
                                            data-day="Day"
                                            data-hour="Hrs"
                                            data-minute="Min"
                                            data-second="Sec"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tt-description">
                                <div class="tt-row">
                                    <ul class="tt-add-info">
                                        <li><a href="#">SKU: 01-001</a></li>
                                        <li><a href="#">VENDER</a></li>
                                        <li><a href="#">CATEGORIE</a></li>
                                    </ul>
                                    <div class="tt-rating">
                                        <i class="icon-star"></i>
                                        <i class="icon-star"></i>
                                        <i class="icon-star"></i>
                                        <i class="icon-star-half"></i>
                                        <i class="icon-star-empty"></i>
                                    </div>
                                </div>
                                <h2 class="tt-title"><a href="product.html">Name product</a></h2>
                                <div class="tt-price">
                                    <span class="new-price">$14</span>
                                    <span class="old-price">$24</span>
                                </div>
                                <div class="tt-option-block">
                                    <ul class="tt-options-swatch">
                                        <li class="active"><a href="#">S</a></li>
                                        <li><a href="#">M</a></li>
                                        <li><a href="#">L</a></li>
                                    </ul>
                                    <ul class="tt-options-swatch">
                                        <li class="active"><a class="options-color tt-color-bg-01" href="#"></a></li>
                                        <li><a class="options-color tt-color-bg-02" href="#"></a></li>
                                    </ul>
                                    <ul class="tt-options-swatch">
                                        <li class="active"><a class="options-color" href="#">
                                            <span class="swatch-img">
                                                <img src="images/custom/texture-img-06.jpg" alt="">
                                            </span>
                                            <span class="swatch-label color-black"></span>
                                        </a></li>
                                        <li><a class="options-color" href="#">
                                            <span class="swatch-img">
                                                <img src="images/custom/texture-img-07.jpg" alt="">
                                            </span>
                                            <span class="swatch-label color-black"></span>
                                        </a></li>
                                        <li><a class="options-color" href="#">
                                            <span class="swatch-img">
                                                <img src="images/custom/texture-img-08.jpg" alt="">
                                            </span>
                                            <span class="swatch-label color-black"></span>
                                        </a></li>
                                    </ul>
                                </div>
                                <div class="tt-product-inside-hover">
                                    <a href="#" class="tt-btn-addtocart" data-toggle="modal" data-target="#modalAddToCartProduct">ADD TO CART</a>
                                    <a href="#" class="tt-btn-quickview" data-toggle="modal" data-target="#ModalquickView"></a>
                                    <a href="product.html" class="tt-btn-link"></a>
                                </div>
                            </div>
                            <a href="#" class="tt-btn-quickview" data-toggle="modal" data-target="#ModalquickView"></a>
                        </div>
                                </div>';
?>