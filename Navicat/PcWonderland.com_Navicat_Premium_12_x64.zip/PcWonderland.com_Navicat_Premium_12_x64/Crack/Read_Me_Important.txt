This file is originally downloaded from PcWonderland.com
Visit PcWonderland.com daily for latest updated versions of all software for free.
We are providing virus free manually checked all working files to download for free.
You can always check our video tutorials if you need help, we make videos on requests also. 
Visit our requests section to request your required software or video tutorials. (pcwonderland.com)
Have a nice day
Mark
PcWonderland.com